import { Component, OnInit, Output } from '@angular/core';
import { User } from 'src/app/interfaces/user';
import { UserService } from 'src/app/services/user.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  public type = ['admin','employee']
  userModel = new User('','',false,'','','','','','')
  @Output()
  public  msg: any

  
  constructor(public service:UserService) { }
  

  ngOnInit(): void {
  }  
  submit(){
    console.log("subit fun",this.userModel);
    this.service.enroll(this.userModel).subscribe(
      data => console.log("sucesss"),
      error => console.log("error")
    )

    
  }

  test(data:any){
    console.log(data)
  }
  
}
