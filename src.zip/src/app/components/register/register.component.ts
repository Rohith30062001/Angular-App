import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Input } from '@angular/core'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  @Input()
  public data: any
  @Output()
  public child = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }
  fire(){
    this.child.emit(this.data)
  }
  
}
