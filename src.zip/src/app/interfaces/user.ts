export class User{
    constructor(
        public username: String,
        public surname: String,
        public remeber: Boolean,
        public type: string,
        public gender:string,
        public dob:any,
        public adress:string,
        public mobile:string,
        public email:string
    ){}
}